//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PIC_Meter.rc
//
#define IDD_PIC_METER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_DLG_SETUP                   129
#define IDC_TXT_RAWDATA                 1000
#define IDC_CHECK_1_USE                 1002
#define IDC_EDIT_1_COLUMN               1003
#define IDC_CMB_1_DATA_FORMAT           1004
#define IDC_EDIT_1_FACTOR               1005
#define IDC_EDIT_1_MIN                  1006
#define IDC_EDIT_1_YCUT                 1007
#define IDC_EDIT_1_MAX                  1008
#define IDC_EDIT_1_TITLE                1009
#define IDC_EDIT_1_METRIC               1010
#define IDC_CMB_PORTNO                  1011
#define IDC_CMB_FILE_OUT                1012
#define IDC_CMB_SPEED                   1013
#define IDC_GRAPH_AREA                  1013
#define IDC_EDIT_XSCALE                 1014
#define IDC_CMB_LINEEND                 1015
#define IDC_CHECK_DELIMIT_SP            1016
#define IDC_CHECK_DELIMIT_COM           1017
#define IDC_EDIT_IGNORE                 1018
#define IDC_CHECK_DELIMIT_TAB           1019
#define IDC_CHECK_DELIMIT_CRLF          1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
